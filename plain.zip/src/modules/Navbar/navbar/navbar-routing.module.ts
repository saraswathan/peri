import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadComponent:()=>
    import('../nav-bar/nav-bar.component').then((x)=>x.NavBarComponent),
    children:[
      {
        path: '',
        loadComponent:()=>
        import('../../Components/routcom/routcom.module').then((x)=>x.RoutcomModule)
      }
    ]
  }


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NavbarRoutingModule { }
