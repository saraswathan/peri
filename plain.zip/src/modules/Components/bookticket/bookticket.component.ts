import { Component, effect, inject, signal } from '@angular/core';
import { BookticketService } from '../service/bookticket/bookticket.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
declare var $: any;

@Component({
  selector: 'app-bookticket',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './bookticket.component.html',
  styleUrl: './bookticket.component.scss'
})
export class BookticketComponent {
  lists: any = [];
  response: any = null;
  sc = inject(BookticketService);
  router = inject(Router);

  constructor() {

    effect(()=>{
      this.buttonText();
      console.log('signal received');      
    });

  }

  ngOnInit(): void {
    this.getBookTicket();
  }

  getBookTicket() {
    this.sc.getseats().subscribe((res) => {
      this.response = res;
      this.lists = this.response?.data;
      console.log(this.lists);
    })

  }


  bookinglist: any[] = [];
  selectSeats(event: any, type: any, id: any) {

    const element = event.target;

    if (element.classList.contains('bi') && element.classList.contains('bi-airplane-engines-fill') && element.classList.contains('icon-large')) {
      return;
    }

    var obj = {
      SeatNo: id,
      SeatType: type,
      Amount: type == 'BS' ? this.findBStotal() : this.findeECotal(),
      Food: false,
      CustomerName: null
    }

    if (element.classList.contains('bi') && element.classList.contains('bi-airplane-engines') && element.classList.contains('text-primary') && element.classList.contains('icon-large')) {
      console.log("unclick");
      element.classList.remove('bi', 'bi-airplane-engines', 'text-primary', 'icon-large');
      element.classList.add('bi', 'bi-airplane-engines', 'icon-large');

      const index = this.bookinglist.findIndex((s: any) => s.SeatNo === id);
      if (index !== -1) {
        this.bookinglist.splice(index, 1);
      }
    }
    else {
      console.log("click");
      element.classList.remove('bi', 'bi-airplane-engines', 'icon-large');
      element.classList.add('bi', 'bi-airplane-engines', 'text-primary', 'icon-large');
      this.bookinglist.push(obj);
    }
    console.log(this.bookinglist, 'this is booking list');
  }

  showbill: boolean = false;

  nextfindfill() {
    
    console.log(this.bookinglist, 'this is booking list');
    for (let i = 0; i < this.bookinglist.length; i++) {
      const name = this.bookinglist[i].CustomerName;
      if (name == null || name == "") {
        return;
      }
    }
    this.totalfillamount();
    this.showbill = true;
  }

  //#region Total Fill amount
  totalamount: any = 0;
  totalfillamount() {

    var total = 0;
    debugger;

    for (let i = 0; i < this.bookinglist.length; i++) {
      if (this.bookinglist[i].Food == true) {
        if (this.bookinglist[i].SeatType == 'BS') {
          total += 500;
        }
        else {
          total += 250;
        }
      }
      total += this.bookinglist[i].Amount;

    }
    this.totalamount = total;
  }
  //#endregion

  //#region find Bussness class tickets booking counts
  findBStotal(): number {
    
    var total = 0;
    console.log(this.lists[0]);
    var filteredArrayLength = this.lists[0].filter((x: any) => x.bookedDate != null).length;
    total = filteredArrayLength * 50 + 5000;
    return total;
  }
  //#endregion

  //#region  find Economic class booking Count
  findeECotal(): number {
    var total = 0;
    var filteredArrayLength = this.lists[1].filter((x: any) => x.bookedDate != null).length;
    total = filteredArrayLength * 25 + 2500;
    return total;
  }
  //#endregion

  PayandBook() {
    debugger
    $('.btn-close').click();

    var obj = this.bookinglist;    
    this.sc.payandbooking(obj).subscribe((res) => {
      console.log(res);
    })      
    this.getBookTicket();
    this.resetbutton();
    setTimeout(() => {
      this.router.navigate(['/Booking/home/BookingDetails']);        
    }, 100);
  }

  bookbtn()
  {
    if(this.bookinglist.length ==0 || this.bookinglist == null){
      Swal.fire({
        title: "Please",
        text: "Select Atleast one Seat..!",
        icon: "warning"
      });
      return;
    }
    $("#staticBackdrop").modal('show');
  }

  resetbutton() {
    this.bookinglist = [];
    this.totalamount = 0;
    this.showbill = false;
  }

buttonText = signal<'Click here' | 'Clicked'>('Click here') ;
  learnsignal(){
    if (this.buttonText() == 'Click here') {
      this.buttonText.set('Clicked');
    } else {
      this.buttonText.set('Click here');
      
    }
  }
}
