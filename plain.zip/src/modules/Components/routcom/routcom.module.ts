import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoutcomRoutingModule } from './routcom-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RoutcomRoutingModule
  ]
})
export class RoutcomModule { }
