import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BookingdetailsService {

  url=environment.apiurl;
  constructor(private _http:HttpClient) { }

  getseats()
  {
    return this._http.get(this.url+'Plain/SeatDetails');
  }

  getbookingDetails()
  {
    return this._http.get(this.url+'Plain/GetBookingDetails');
  }


}
