import { Routes } from '@angular/router';
import { NavbarModule } from '../modules/Navbar/navbar/navbar.module';
import { NavBarComponent } from '../modules/Navbar/nav-bar/nav-bar.component';

export const routes: Routes = [
    { path: '', redirectTo: 'Booking', pathMatch: 'full' },
    // // {path:'Booking', component:NavBarComponent},
    {path:'Booking', loadChildren:()=>
                        import("../modules/Navbar/navbar/navbar.module").then((x)=>x.NavbarModule)
        },
];
