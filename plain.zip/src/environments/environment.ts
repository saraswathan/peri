
export const localurl="https://localhost:44374";

export const environment = {
    production:false,
    apiurl : localurl+'/api/',
};
