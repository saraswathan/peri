import { Routes } from '@angular/router';
import { LoginAuthComponent } from '../login-auth/login-auth.component';

export const routes: Routes = [
    {
        path: '',
        component:LoginAuthComponent        
    },
    {
        path:'firstProject',
        loadChildren:()=>
        import('../modules/navBar/navbarmod/navbarmod.module').then((x)=>x.NavbarmodModule)
    }
];
