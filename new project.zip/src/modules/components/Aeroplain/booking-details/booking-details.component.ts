import { Component } from '@angular/core';
import { BookingdetailsService } from '../service/bookingDetails/bookingdetails.service';

@Component({
  selector: 'app-booking-details',
  standalone: true,
  imports: [],
  templateUrl: './booking-details.component.html',
  styleUrl: './booking-details.component.scss'
})
export class BookingDetailsComponent {

  response:any=null
  list:any[]=[]
  constructor(private sc:BookingdetailsService) { }

  ngOnInit(): void {
    this.GetDetailsBookinglist();
    
  }


  GetDetailsBookinglist()
  {
    this.sc.getbookingDetails().subscribe((res)=>{
      this.response=res;
      this.list=this.response?.data;
      console.log(this.list);
    })
  }



}
