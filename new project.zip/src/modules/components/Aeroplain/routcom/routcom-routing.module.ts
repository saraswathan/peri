import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '', redirectTo: 'Bookticket', pathMatch: 'full'
  },
  {
    path: 'Bookticket', loadComponent: () =>
      import('../bookticket/bookticket.component').then((x) => x.BookticketComponent)
  },
  {
    path:'BookingDetails',loadComponent:()=>
    import('../booking-details/booking-details.component').then((x)=> x.BookingDetailsComponent)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RoutcomRoutingModule { }
