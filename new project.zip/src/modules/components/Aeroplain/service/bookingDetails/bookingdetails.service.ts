import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BookingdetailsService {

  url=environment.apiurl;
  constructor(private _http:HttpClient) { }

  getseats()
  {
    return this._http.get(this.url+'Plain/SeatDetails');
  }

  getbookingDetails()
  {
    return this._http.get(this.url+'Plain/GetBookingDetails');
  }


}
