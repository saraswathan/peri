import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BookticketService {

  url = environment.apiurl;
  constructor(private _http:HttpClient) { }

  getseats()
  {
    return this._http.get(this.url+'Plain/SeatDetails');
  }
  

  payandbooking(obj:any){
    return this._http.post(this.url+'Plain/BookTicket',obj);
  }

  

}
