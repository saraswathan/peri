import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NavbarmodRoutingModule } from './navbarmod-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    NavbarmodRoutingModule
  ]
})
export class NavbarmodModule { }
