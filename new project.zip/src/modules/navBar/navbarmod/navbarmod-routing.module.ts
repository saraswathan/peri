import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path:'',
    loadComponent:()=>
    import('../navbar/navbar.component').then(m=>m.NavbarComponent),
    children:[
      {
        path:'',
        loadComponent:()=>
        import('../../components/Home/dash-board/dash-board.component').then(m=>m.DashBoardComponent)
      },
      {
        path:'Aeroplain',
        loadChildren:()=>
        import('../../components/Aeroplain/routcom/routcom.module').then(m=>m.RoutcomModule)
      }
    ]

  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NavbarmodRoutingModule { }
