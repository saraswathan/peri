import { Component,inject } from '@angular/core';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-login-auth',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './login-auth.component.html',
  styleUrl: './login-auth.component.scss'
})
export class LoginAuthComponent {
  router = inject(Router);

  constructor(){}

  ngOnInit(): void {
    
  }

  loginBtn(){    
      // this.router.navigateByUrl('firstProject');
  }


}
