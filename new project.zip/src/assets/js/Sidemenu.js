document.getElementById("topnav-hamburger-icon")?.addEventListener("click", function () {

    console.log(document.getElementById('sidemenu'))

    if (document.getElementById('Id_hamburger')?.classList.contains('open')) {
        document.getElementById('Id_hamburger')?.classList.remove("open");
    } else {
        document.getElementById('Id_hamburger')?.classList.add("open");
    }

});